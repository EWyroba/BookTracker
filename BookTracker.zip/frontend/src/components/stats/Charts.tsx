import React, { useState, useEffect } from 'react';
import styled from 'styled-components';
import { booksAPI } from '../../services/api';
import Icon from '../common/Icon';

const StatsContainer = styled.div`
  padding: ${props => props.theme.spacing.xl} 0;
`;

const StatsHeader = styled.div`
  text-align: center;
  margin-bottom: ${props => props.theme.spacing.xl};
`;

const StatsTitle = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.colors.text};
  margin-bottom: ${props => props.theme.spacing.md};
`;

const StatsSubtitle = styled.p`
  color: ${props => props.theme.colors.textSecondary};
  font-size: 1.1rem;
`;

const OverviewGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: ${props => props.theme.spacing.lg};
  margin-bottom: ${props => props.theme.spacing.xl};
`;

const StatCard = styled.div`
  background: ${props => props.theme.colors.surface};
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: ${props => props.theme.borderRadius.lg};
  padding: ${props => props.theme.spacing.xl};
  text-align: center;
  transition: transform 0.2s ease;

  &:hover {
    transform: translateY(-2px);
  }
`;

const StatIcon = styled.div`
  width: 60px;
  height: 60px;
  background: ${props => props.theme.colors.primary}20;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto ${props => props.theme.spacing.md};

  svg {
    font-size: 1.5rem;
    color: ${props => props.theme.colors.primary};
  }
`;

const StatValue = styled.div`
  font-size: 2rem;
  font-weight: bold;
  color: ${props => props.theme.colors.primary};
  margin-bottom: ${props => props.theme.spacing.xs};
`;

const StatLabel = styled.div`
  color: ${props => props.theme.colors.textSecondary};
  font-size: 0.9rem;
`;

const ChartsGrid = styled.div`
  display: grid;
  grid-template-columns: 1fr;
  gap: ${props => props.theme.spacing.lg};
  margin-bottom: ${props => props.theme.spacing.xl};

  @media (min-width: 768px) {
    grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
  }
`;

const ChartCard = styled.div`
  background: ${props => props.theme.colors.surface};
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: ${props => props.theme.borderRadius.lg};
  padding: ${props => props.theme.spacing.xl};
`;

const ChartTitle = styled.h2`
  font-size: 1.3rem;
  font-weight: 600;
  margin-bottom: ${props => props.theme.spacing.lg};
  color: ${props => props.theme.colors.text};
`;

const GoalSection = styled.div`
  background: ${props => props.theme.colors.surface};
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: ${props => props.theme.borderRadius.lg};
  padding: ${props => props.theme.spacing.xl};
  margin-bottom: ${props => props.theme.spacing.xl};
`;

const GoalHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${props => props.theme.spacing.lg};
`;

const GoalTitle = styled.h2`
  font-size: 1.3rem;
  font-weight: 600;
  color: ${props => props.theme.colors.text};
`;

const GoalProgress = styled.div`
  margin-bottom: ${props => props.theme.spacing.md};
`;

const ProgressBar = styled.div`
  height: 12px;
  background: ${props => props.theme.colors.border};
  border-radius: 6px;
  overflow: hidden;
  margin-bottom: ${props => props.theme.spacing.sm};
`;

const ProgressFill = styled.div<{ $progress: number }>`
  height: 100%;
  background: ${props => props.theme.colors.primary};
  width: ${props => props.$progress}%;
  transition: width 0.5s ease;
`;

const ProgressText = styled.div`
  display: flex;
  justify-content: space-between;
  color: ${props => props.theme.colors.textSecondary};
  font-size: 0.9rem;
`;

const LoadingState = styled.div`
  text-align: center;
  padding: ${props => props.theme.spacing.xxl};
  color: ${props => props.theme.colors.textSecondary};
`;

const ErrorState = styled.div`
  text-align: center;
  padding: ${props => props.theme.spacing.xxl};
  color: ${props => props.theme.colors.error};
`;

const SimpleChart = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.md};
  margin-top: ${props => props.theme.spacing.lg};
`;

// POPRAWIONE: Usunięte styled components z błędami i zastąpione prostszymi
const ChartItem = styled.div`
  display: flex;
  align-items: center;
  gap: ${props => props.theme.spacing.md};
  padding: ${props => props.theme.spacing.sm} 0;
`;

const ChartLabel = styled.span`
  min-width: 120px;
  color: ${props => props.theme.colors.text};
  font-size: 0.9rem;
`;

const ChartBarContainer = styled.div`
  flex: 1;
  height: 20px;
  background: ${props => props.theme.colors.border};
  border-radius: 10px;
  overflow: hidden;
`;

const ChartBarFill = styled.div<{ $percentage: number; $color: string }>`
  height: 100%;
  background: ${props => props.$color};
  width: ${props => props.$percentage}%;
  transition: width 0.5s ease;
  border-radius: 10px;
`;

const ChartValue = styled.span`
  min-width: 40px;
  text-align: right;
  color: ${props => props.theme.colors.textSecondary};
  font-size: 0.9rem;
`;

interface OverviewStats {
    booksRead: number;
    currentlyReading: number;
    totalPages: number;
    readingTime: number;
}

interface GenreStats {
    gatunek: string;
    count: number;
}

interface ReadingGoal {
    goal: number;
    current: number;
    progress: number;
    remaining: number;
}

// Kolory dla wykresów
const COLORS = ['#00b4db', '#0083b0', '#ff6b6b', '#4ecdc4', '#45b7d1', '#96ceb4', '#feca57', '#ff9ff3', '#54a0ff', '#5f27cd'];

const Charts: React.FC = () => {
    const [overview, setOverview] = useState<OverviewStats | null>(null);
    const [genres, setGenres] = useState<GenreStats[]>([]);
    const [yearlyReading, setYearlyReading] = useState<any[]>([]);
    const [readingGoal, setReadingGoal] = useState<ReadingGoal | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    const fetchStats = async () => {
        try {
            const [overviewResponse, goalsResponse] = await Promise.all([
                booksAPI.get('/stats/overview'),
                booksAPI.get('/stats/reading-goals')
            ]);

            setOverview(overviewResponse.data.overview);
            setGenres(overviewResponse.data.genres || []);
            setYearlyReading(overviewResponse.data.yearlyReading || []);
            setReadingGoal(goalsResponse.data);
        } catch (err: any) {
            console.error('Error fetching stats:', err);
            setError(err.response?.data?.message || 'Wystąpił błąd podczas ładowania statystyk');
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchStats();
    }, []);

    // Oblicz maksymalną wartość dla skalowania wykresów
    const maxGenreCount = genres.length > 0 ? Math.max(...genres.map(g => g.count)) : 0;
    const maxMonthlyBooks = yearlyReading.length > 0 ? Math.max(...yearlyReading.map(m => m.books_read)) : 0;

    if (loading) {
        return (
            <StatsContainer>
                <div className="container">
                    <LoadingState>
                        <div>Ładowanie statystyk...</div>
                    </LoadingState>
                </div>
            </StatsContainer>
        );
    }

    if (error) {
        return (
            <StatsContainer>
                <div className="container">
                    <ErrorState>
                        <div>{error}</div>
                    </ErrorState>
                </div>
            </StatsContainer>
        );
    }

    return (
        <StatsContainer>
            <div className="container">
                <StatsHeader>
                    <StatsTitle>Statystyki Czytania</StatsTitle>
                    <StatsSubtitle>
                        Śledź swoje postępy i odkrywaj nawyki czytelnicze
                    </StatsSubtitle>
                </StatsHeader>

                {overview && (
                    <OverviewGrid>
                        <StatCard>
                            <StatIcon>
                                <Icon name="FiBook" />
                            </StatIcon>
                            <StatValue>{overview.booksRead}</StatValue>
                            <StatLabel>Przeczytane książki</StatLabel>
                        </StatCard>

                        <StatCard>
                            <StatIcon>
                                <Icon name="FiBookOpen" />
                            </StatIcon>
                            <StatValue>{overview.currentlyReading}</StatValue>
                            <StatLabel>Aktualnie czytane</StatLabel>
                        </StatCard>

                        <StatCard>
                            <StatIcon>
                                <Icon name="FiTrendingUp" />
                            </StatIcon>
                            <StatValue>{overview.totalPages}</StatValue>
                            <StatLabel>Przeczytane strony</StatLabel>
                        </StatCard>

                        <StatCard>
                            <StatIcon>
                                <Icon name="FiClock" />
                            </StatIcon>
                            <StatValue>{overview.readingTime}</StatValue>
                            <StatLabel>Godziny czytania</StatLabel>
                        </StatCard>
                    </OverviewGrid>
                )}

                {readingGoal && readingGoal.goal > 0 && (
                    <GoalSection>
                        <GoalHeader>
                            <GoalTitle>Cel czytelniczy na rok</GoalTitle>
                        </GoalHeader>
                        <GoalProgress>
                            <ProgressBar>
                                <ProgressFill $progress={readingGoal.progress} />
                            </ProgressBar>
                            <ProgressText>
                                <span>{readingGoal.current} / {readingGoal.goal} książek</span>
                                <span>{Math.round(readingGoal.progress)}%</span>
                            </ProgressText>
                        </GoalProgress>
                        <div style={{ color: '#666', fontSize: '0.9rem' }}>
                            Do celu pozostało: {readingGoal.remaining} książek
                        </div>
                    </GoalSection>
                )}

                <ChartsGrid>
                    {/* Wykres gatunków - własna implementacja */}
                    {genres.length > 0 && (
                        <ChartCard>
                            <ChartTitle>Ulubione gatunki</ChartTitle>
                            <SimpleChart>
                                {genres.map((genre, index) => (
                                    <ChartItem key={genre.gatunek}>
                                        <ChartLabel>{genre.gatunek}</ChartLabel>
                                        <ChartBarContainer>
                                            <ChartBarFill
                                                $percentage={maxGenreCount > 0 ? (genre.count / maxGenreCount) * 100 : 0}
                                                $color={COLORS[index % COLORS.length]}
                                            />
                                        </ChartBarContainer>
                                        <ChartValue>{genre.count}</ChartValue>
                                    </ChartItem>
                                ))}
                            </SimpleChart>
                        </ChartCard>
                    )}

                    {/* Wykres czytania w ciągu roku - własna implementacja */}
                    {yearlyReading.length > 0 && (
                        <ChartCard>
                            <ChartTitle>Czytanie w tym roku</ChartTitle>
                            <SimpleChart>
                                {yearlyReading.map((item, index) => (
                                    <ChartItem key={item.month || index}>
                                        <ChartLabel>{item.month || `Miesiąc ${index + 1}`}</ChartLabel>
                                        <ChartBarContainer>
                                            <ChartBarFill
                                                $percentage={maxMonthlyBooks > 0 ? (item.books_read / maxMonthlyBooks) * 100 : 0}
                                                $color="#00b4db"
                                            />
                                        </ChartBarContainer>
                                        <ChartValue>{item.books_read}</ChartValue>
                                    </ChartItem>
                                ))}
                            </SimpleChart>
                        </ChartCard>
                    )}
                </ChartsGrid>

                {/* Komunikat jeśli brak danych */}
                {(!overview || (genres.length === 0 && yearlyReading.length === 0)) && (
                    <div style={{ textAlign: 'center', padding: '2rem', color: '#666' }}>
                        <Icon name="FiBook" size={48} />
                        <h3>Brak danych statystycznych</h3>
                        <p>Dodaj książki i oznacz je jako przeczytane, aby zobaczyć statystyki.</p>
                    </div>
                )}
            </div>
        </StatsContainer>
    );
};

export default Charts;