import React from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';
import Icon from '../common/Icon';

interface ProgressFillProps {
    $progress: number;
}

const DashboardContainer = styled.div`
  padding: ${props => props.theme.spacing.xl} 0;
`;

const WelcomeSection = styled.section`
  background: linear-gradient(135deg, ${props => props.theme.colors.primary}, ${props => props.theme.colors.primaryDark});
  padding: ${props => props.theme.spacing.xxl};
  border-radius: ${props => props.theme.borderRadius.lg};
  margin-bottom: ${props => props.theme.spacing.xxl};
  text-align: center;
`;

const WelcomeTitle = styled.h1`
  font-size: 2.5rem;
  margin-bottom: ${props => props.theme.spacing.md};
  font-weight: 700;
`;

const WelcomeSubtitle = styled.p`
  font-size: 1.2rem;
  color: rgba(255, 255, 255, 0.9);
  margin-bottom: ${props => props.theme.spacing.lg};
`;

const StatsGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: ${props => props.theme.spacing.lg};
  margin-bottom: ${props => props.theme.spacing.xxl};
`;

const StatCard = styled.div`
  background: ${props => props.theme.colors.surface};
  padding: ${props => props.theme.spacing.xl};
  border-radius: ${props => props.theme.borderRadius.lg};
  border: 1px solid ${props => props.theme.colors.border};
  text-align: center;
  transition: transform 0.2s ease, box-shadow 0.2s ease;

  &:hover {
    transform: translateY(-4px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.3);
  }
`;

const StatIcon = styled.div`
  width: 60px;
  height: 60px;
  background: ${props => props.theme.colors.primary}20;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto ${props => props.theme.spacing.md};

  svg {
    font-size: 1.5rem;
    color: ${props => props.theme.colors.primary};
  }
`;

const StatValue = styled.div`
  font-size: 2rem;
  font-weight: bold;
  color: ${props => props.theme.colors.primary};
  margin-bottom: ${props => props.theme.spacing.xs};
`;

const StatLabel = styled.div`
  color: ${props => props.theme.colors.textSecondary};
  font-size: 0.9rem;
`;

const Section = styled.section`
  margin-bottom: ${props => props.theme.spacing.xxl};
`;

const SectionHeader = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: ${props => props.theme.spacing.lg};
`;

const SectionTitle = styled.h2`
  font-size: 1.5rem;
  font-weight: 600;
`;

const SectionLink = styled(Link)`
  color: ${props => props.theme.colors.primary};
  font-weight: 500;
  text-decoration: none;

  &:hover {
    text-decoration: underline;
  }
`;

const BooksGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(180px, 1fr));
  gap: ${props => props.theme.spacing.lg};
`;

// Zmieniamy nazwę lokalnego komponentu na DashboardBookCard
const DashboardBookCard = styled.div`
  background: ${props => props.theme.colors.surface};
  border-radius: ${props => props.theme.borderRadius.md};
  overflow: hidden;
  border: 1px solid ${props => props.theme.colors.border};
  transition: transform 0.2s ease;

  &:hover {
    transform: translateY(-2px);
  }
`;

const BookCover = styled.img`
  width: 100%;
  height: 240px;
  object-fit: cover;
  background: ${props => props.theme.colors.surfaceLight};
`;

const BookInfo = styled.div`
  padding: ${props => props.theme.spacing.md};
`;

const BookTitle = styled.h3`
  font-size: 0.9rem;
  font-weight: 600;
  margin-bottom: ${props => props.theme.spacing.xs};
  line-height: 1.3;
`;

const BookAuthor = styled.p`
  font-size: 0.8rem;
  color: ${props => props.theme.colors.textSecondary};
`;

const ProgressBar = styled.div`
  height: 4px;
  background: ${props => props.theme.colors.border};
  border-radius: 2px;
  margin-top: ${props => props.theme.spacing.sm};
  overflow: hidden;
`;

const ProgressFill = styled.div<ProgressFillProps>`
  height: 100%;
  background: ${props => props.theme.colors.primary};
  width: ${props => props.$progress}%;
  transition: width 0.3s ease;
`;

const Dashboard: React.FC = () => {
    // Tymczasowe dane - później zastąpimy danymi z API
    const stats = {
        totalBooks: 24,
        readingGoal: 52,
        pagesRead: 8450,
        readingTime: 142
    };

    const recentBooks = [
        {
            id: 1,
            title: 'Ostatnie życzenie',
            author: 'Andrzej Sapkowski',
            cover: 'https://via.placeholder.com/180x240/1a1a1a/666666?text=Okładka',
            progress: 100
        },
        {
            id: 2,
            title: 'Harry Potter i Kamień Filozoficzny',
            author: 'J.K. Rowling',
            cover: 'https://via.placeholder.com/180x240/1a1a1a/666666?text=Okładka',
            progress: 100
        },
        {
            id: 3,
            title: 'Księgi Jakubowe',
            author: 'Olga Tokarczuk',
            cover: 'https://via.placeholder.com/180x240/1a1a1a/666666?text=Okładka',
            progress: 49
        },
        {
            id: 4,
            title: 'Miecz przeznaczenia',
            author: 'Andrzej Sapkowski',
            cover: 'https://via.placeholder.com/180x240/1a1a1a/666666?text=Okładka',
            progress: 43
        }
    ];

    const currentlyReading = recentBooks.filter(book => book.progress > 0 && book.progress < 100);

    return (
        <DashboardContainer>
            <div className="container">
                <WelcomeSection>
                    <WelcomeTitle>Witaj w BookTracker!</WelcomeTitle>
                    <WelcomeSubtitle>
                        Śledź swoje postępy w czytaniu, odkrywaj nowe książki i osiągaj cele czytelnicze
                    </WelcomeSubtitle>
                </WelcomeSection>

                <StatsGrid>
                    <StatCard>
                        <StatIcon>
                            <Icon name="FiBook" />
                        </StatIcon>
                        <StatValue>{stats.totalBooks}</StatValue>
                        <StatLabel>Przeczytane książki</StatLabel>
                    </StatCard>

                    <StatCard>
                        <StatIcon>
                            <Icon name="FiAward" />
                        </StatIcon>
                        <StatValue>{stats.readingGoal}</StatValue>
                        <StatLabel>Cel na rok</StatLabel>
                    </StatCard>

                    <StatCard>
                        <StatIcon>
                            <Icon name="FiTrendingUp" />
                        </StatIcon>
                        <StatValue>{stats.pagesRead}</StatValue>
                        <StatLabel>Przeczytane strony</StatLabel>
                    </StatCard>

                    <StatCard>
                        <StatIcon>
                            <Icon name="FiClock" />
                        </StatIcon>
                        <StatValue>{stats.readingTime}h</StatValue>
                        <StatLabel>Czas czytania</StatLabel>
                    </StatCard>
                </StatsGrid>

                <Section>
                    <SectionHeader>
                        <SectionTitle>Aktualnie czytane</SectionTitle>
                        <SectionLink to="/books">Zobacz wszystkie</SectionLink>
                    </SectionHeader>

                    <BooksGrid>
                        {currentlyReading.map(book => (
                            <DashboardBookCard key={book.id}>
                                <BookCover src={book.cover} alt={book.title} />
                                <BookInfo>
                                    <BookTitle>{book.title}</BookTitle>
                                    <BookAuthor>{book.author}</BookAuthor>
                                    <ProgressBar>
                                        <ProgressFill $progress={book.progress} />
                                    </ProgressBar>
                                </BookInfo>
                            </DashboardBookCard>
                        ))}
                    </BooksGrid>
                </Section>

                <Section>
                    <SectionHeader>
                        <SectionTitle>Ostatnio przeczytane</SectionTitle>
                        <SectionLink to="/books?status=przeczytana">Zobacz wszystkie</SectionLink>
                    </SectionHeader>

                    <BooksGrid>
                        {recentBooks.filter(book => book.progress === 100).map(book => (
                            <DashboardBookCard key={book.id}>
                                <BookCover src={book.cover} alt={book.title} />
                                <BookInfo>
                                    <BookTitle>{book.title}</BookTitle>
                                    <BookAuthor>{book.author}</BookAuthor>
                                </BookInfo>
                            </DashboardBookCard>
                        ))}
                    </BooksGrid>
                </Section>
            </div>
        </DashboardContainer>
    );
};

export default Dashboard;