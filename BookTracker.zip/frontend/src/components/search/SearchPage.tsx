import React from 'react';
import styled from 'styled-components';

const SearchContainer = styled.div`
  padding: ${props => props.theme.spacing.xl} 0;
  text-align: center;
`;

const SearchTitle = styled.h1`
  font-size: 2rem;
  font-weight: 700;
  color: ${props => props.theme.colors.text};
  margin-bottom: ${props => props.theme.spacing.md};
`;

const SearchMessage = styled.p`
  color: ${props => props.theme.colors.textSecondary};
  font-size: 1.1rem;
`;

const SearchPage: React.FC = () => {
    return (
        <SearchContainer>
            <div className="container">
                <SearchTitle>Wyszukiwarka Książek</SearchTitle>
                <SearchMessage>
                    Moduł wyszukiwania jest w trakcie implementacji.
                    <br />
                    Będzie dostępny wkrótce!
                </SearchMessage>
            </div>
        </SearchContainer>
    );
};

export default SearchPage;