import React, { useState } from 'react';
import styled from 'styled-components';
import { booksAPI } from '../../services/api';

const FormOverlay = styled.div`
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.7);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 1000;
`;

const FormContainer = styled.div`
  background: ${props => props.theme.colors.surface};
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: ${props => props.theme.borderRadius.lg};
  padding: ${props => props.theme.spacing.xl};
  width: 90%;
  max-width: 500px;
  max-height: 90vh;
  overflow-y: auto;
`;

const FormTitle = styled.h2`
  margin-bottom: ${props => props.theme.spacing.lg};
  color: ${props => props.theme.colors.text};
`;

const Form = styled.form`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.lg};
`;

const FormGroup = styled.div`
  display: flex;
  flex-direction: column;
  gap: ${props => props.theme.spacing.sm};
`;

const Label = styled.label`
  color: ${props => props.theme.colors.text};
  font-weight: 500;
`;

const Input = styled.input`
  padding: ${props => props.theme.spacing.md};
  background: ${props => props.theme.colors.background};
  border: 1px solid ${props => props.theme.colors.border};
  border-radius: ${props => props.theme.borderRadius.md};
  color: ${props => props.theme.colors.text};
  font-size: 1rem;

  &:focus {
    border-color: ${props => props.theme.colors.primary};
    outline: none;
  }
`;

const ButtonGroup = styled.div`
  display: flex;
  gap: ${props => props.theme.spacing.md};
  margin-top: ${props => props.theme.spacing.lg};
`;

const Button = styled.button<{ $variant?: 'primary' | 'secondary' }>`
  padding: ${props => props.theme.spacing.md} ${props => props.theme.spacing.lg};
  border: none;
  border-radius: ${props => props.theme.borderRadius.md};
  font-weight: 600;
  cursor: pointer;
  flex: 1;
  transition: all 0.2s ease;

  ${props => props.$variant === 'primary' ? `
    background: ${props.theme.colors.primary};
    color: white;
    
    &:hover {
      background: ${props.theme.colors.primaryDark};
    }
  ` : `
    background: ${props.theme.colors.surfaceLight};
    color: ${props.theme.colors.text};
    
    &:hover {
      background: ${props.theme.colors.border};
    }
  `}

  &:disabled {
    opacity: 0.6;
    cursor: not-allowed;
  }
`;

const ErrorMessage = styled.div`
  background: ${props => props.theme.colors.error}20;
  border: 1px solid ${props => props.theme.colors.error};
  color: ${props => props.theme.colors.error};
  padding: ${props => props.theme.spacing.md};
  border-radius: ${props => props.theme.borderRadius.md};
  text-align: center;
`;

interface AddBookFormProps {
    onCancel: () => void;
    onSuccess: () => void;
}

const AddBookForm: React.FC<AddBookFormProps> = ({ onCancel, onSuccess }) => {
    const [formData, setFormData] = useState({
        tytul: '',
        autor: '',
        isbn: '',
        liczba_stron: '',
        gatunek: '',
        url_okladki: ''
    });
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData(prev => ({
            ...prev,
            [e.target.name]: e.target.value
        }));
        setError('');
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (!formData.tytul.trim()) {
            setError('Tytuł jest wymagany');
            return;
        }

        setLoading(true);
        setError('');

        try {
            await booksAPI.post('/books', {
                ...formData,
                liczba_stron: formData.liczba_stron ? parseInt(formData.liczba_stron) : null
            });

            onSuccess();
        } catch (err: any) {
            setError(err.response?.data?.message || 'Wystąpił błąd podczas dodawania książki');
        } finally {
            setLoading(false);
        }
    };

    return (
        <FormOverlay onClick={onCancel}>
            <FormContainer onClick={e => e.stopPropagation()}>
                <FormTitle>Dodaj nową książkę</FormTitle>

                <Form onSubmit={handleSubmit}>
                    {error && <ErrorMessage>{error}</ErrorMessage>}

                    <FormGroup>
                        <Label htmlFor="tytul">Tytuł *</Label>
                        <Input
                            type="text"
                            id="tytul"
                            name="tytul"
                            value={formData.tytul}
                            onChange={handleChange}
                            placeholder="Wprowadź tytuł książki"
                            required
                        />
                    </FormGroup>

                    <FormGroup>
                        <Label htmlFor="autor">Autor</Label>
                        <Input
                            type="text"
                            id="autor"
                            name="autor"
                            value={formData.autor}
                            onChange={handleChange}
                            placeholder="Wprowadź autora"
                        />
                    </FormGroup>

                    <FormGroup>
                        <Label htmlFor="isbn">ISBN</Label>
                        <Input
                            type="text"
                            id="isbn"
                            name="isbn"
                            value={formData.isbn}
                            onChange={handleChange}
                            placeholder="Numer ISBN"
                        />
                    </FormGroup>

                    <FormGroup>
                        <Label htmlFor="liczba_stron">Liczba stron</Label>
                        <Input
                            type="number"
                            id="liczba_stron"
                            name="liczba_stron"
                            value={formData.liczba_stron}
                            onChange={handleChange}
                            placeholder="Ilość stron"
                        />
                    </FormGroup>

                    <FormGroup>
                        <Label htmlFor="gatunek">Gatunek</Label>
                        <Input
                            type="text"
                            id="gatunek"
                            name="gatunek"
                            value={formData.gatunek}
                            onChange={handleChange}
                            placeholder="np. fantasy, kryminał, romans"
                        />
                    </FormGroup>

                    <FormGroup>
                        <Label htmlFor="url_okladki">URL okładki</Label>
                        <Input
                            type="url"
                            id="url_okladki"
                            name="url_okladki"
                            value={formData.url_okladki}
                            onChange={handleChange}
                            placeholder="https://example.com/okladka.jpg"
                        />
                    </FormGroup>

                    <ButtonGroup>
                        <Button type="button" $variant="secondary" onClick={onCancel} disabled={loading}>
                            Anuluj
                        </Button>
                        <Button type="submit" $variant="primary" disabled={loading}>
                            {loading ? 'Dodawanie...' : 'Dodaj książkę'}
                        </Button>
                    </ButtonGroup>
                </Form>
            </FormContainer>
        </FormOverlay>
    );
};

export default AddBookForm;