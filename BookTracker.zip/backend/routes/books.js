const express = require('express');
const { authenticateToken } = require('../middleware/auth');
const router = express.Router();

// Pobierz wszystkie książki użytkownika
router.get('/', authenticateToken, async (req, res) => {
    try {
        const db = require('../config/database');

        const [books] = await db.promisePool.execute(`
      SELECT k.*, 
             s.status, 
             s.aktualna_strona, 
             s.ocena,
             s.data_rozpoczecia,
             s.data_zakonczenia
      FROM ksiazki k 
      LEFT JOIN statusy_czytania s ON k.id = s.ksiazka_id AND s.uzytkownik_id = ?
      ORDER BY k.id DESC
    `, [req.user.userId]);

        res.json({ books });
    } catch (error) {
        console.error('Get books error:', error);
        res.status(500).json({ message: 'Błąd serwera', error: error.message });
    }
});

// Pobierz pojedynczą książkę
router.get('/:id', authenticateToken, async (req, res) => {
    try {
        const db = require('../config/database');
        const bookId = req.params.id;

        const [books] = await db.promisePool.execute(`
      SELECT k.*, 
             s.status, 
             s.aktualna_strona, 
             s.ocena,
             s.recenzja,
             s.data_rozpoczecia,
             s.data_zakonczenia
      FROM ksiazki k 
      LEFT JOIN statusy_czytania s ON k.id = s.ksiazka_id AND s.uzytkownik_id = ?
      WHERE k.id = ?
    `, [req.user.userId, bookId]);

        if (books.length === 0) {
            return res.status(404).json({ message: 'Książka nie znaleziona' });
        }

        res.json({ book: books[0] });
    } catch (error) {
        console.error('Get book error:', error);
        res.status(500).json({ message: 'Błąd serwera', error: error.message });
    }
});

// Dodaj nową książkę z autorami
router.post('/', authenticateToken, async (req, res) => {
    try {
        const { tytul, autor, isbn, liczba_stron, gatunek, url_okladki } = req.body;
        const db = require('../config/database');

        if (!tytul) {
            return res.status(400).json({ message: 'Tytuł jest wymagany' });
        }

        // Rozpocznij transakcję
        const connection = await db.promisePool.getConnection();
        await connection.beginTransaction();

        try {
            // 1. Dodaj książkę
            const [bookResult] = await connection.execute(
                'INSERT INTO ksiazki (tytul, isbn, liczba_stron, gatunek, url_okladki) VALUES (?, ?, ?, ?, ?)',
                [tytul, isbn || '', liczba_stron || null, gatunek || '', url_okladki || '']
            );

            const bookId = bookResult.insertId;

            // 2. Jeśli podano autora, dodaj go
            if (autor && autor.trim()) {
                // Sprawdź czy autor już istnieje
                const [existingAuthors] = await connection.execute(
                    'SELECT id FROM autorzy WHERE imie_nazwisko = ?',
                    [autor.trim()]
                );

                let authorId;

                if (existingAuthors.length > 0) {
                    authorId = existingAuthors[0].id;
                } else {
                    // Dodaj nowego autora
                    const [authorResult] = await connection.execute(
                        'INSERT INTO autorzy (imie_nazwisko) VALUES (?)',
                        [autor.trim()]
                    );
                    authorId = authorResult.insertId;
                }

                // Połącz książkę z autorem
                await connection.execute(
                    'INSERT INTO ksiazka_autorzy (ksiazka_id, autor_id) VALUES (?, ?)',
                    [bookId, authorId]
                );
            }

            await connection.commit();

            res.status(201).json({
                message: 'Książka dodana pomyślnie',
                bookId: bookId
            });

        } catch (error) {
            await connection.rollback();
            throw error;
        } finally {
            connection.release();
        }

    } catch (error) {
        console.error('Add book error:', error);
        res.status(500).json({ message: 'Błąd serwera', error: error.message });
    }
});

// Aktualizuj status czytania - POPRAWIONA WERSJA
router.post('/:id/status', authenticateToken, async (req, res) => {
    try {
        const { status, aktualna_strona, ocena, recenzja } = req.body;
        const bookId = req.params.id;
        const userId = req.user.userId;

        console.log('Update status request:', { userId, bookId, status, aktualna_strona });

        const db = require('../config/database');

        // Sprawdź czy książka istnieje
        const [books] = await db.promisePool.execute('SELECT id FROM ksiazki WHERE id = ?', [bookId]);
        if (books.length === 0) {
            return res.status(404).json({ message: 'Książka nie znaleziona' });
        }

        // Sprawdź czy status już istnieje
        const [existingStatus] = await db.promisePool.execute(
            'SELECT * FROM statusy_czytania WHERE uzytkownik_id = ? AND ksiazka_id = ?',
            [userId, bookId]
        );

        let data_rozpoczecia = null;
        let data_zakonczenia = null;

        // Ustaw daty na podstawie statusu
        if (status === 'aktualnie_czytam') {
            data_rozpoczecia = new Date().toISOString().split('T')[0];
        } else if (status === 'przeczytana') {
            data_zakonczenia = new Date().toISOString().split('T')[0];
            // Jeśli nie ma daty rozpoczęcia, ustaw ją
            if (existingStatus.length > 0 && !existingStatus[0].data_rozpoczecia) {
                data_rozpoczecia = new Date().toISOString().split('T')[0];
            }
        }

        // Ustaw domyślne wartości
        const finalAktualnaStrona = aktualna_strona || 0;
        const finalOcena = ocena || null;
        const finalRecenzja = recenzja || null;

        console.log('Final values:', { data_rozpoczecia, data_zakonczenia, finalAktualnaStrona });

        if (existingStatus.length > 0) {
            // Aktualizuj istniejący status - POPRAWIONE ZAPYTANIE
            const [result] = await db.promisePool.execute(
                `UPDATE statusy_czytania 
         SET status = ?, aktualna_strona = ?, ocena = ?, recenzja = ?, 
             data_rozpoczecia = COALESCE(?, data_rozpoczecia), 
             data_zakonczenia = ?
         WHERE uzytkownik_id = ? AND ksiazka_id = ?`,
                [status, finalAktualnaStrona, finalOcena, finalRecenzja, data_rozpoczecia, data_zakonczenia, userId, bookId]
            );

            console.log('Status updated, affected rows:', result.affectedRows);
        } else {
            // Dodaj nowy status - POPRAWIONE ZAPYTANIE
            const [result] = await db.promisePool.execute(
                'INSERT INTO statusy_czytania (uzytkownik_id, ksiazka_id, status, aktualna_strona, ocena, recenzja, data_rozpoczecia, data_zakonczenia) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
                [userId, bookId, status, finalAktualnaStrona, finalOcena, finalRecenzja, data_rozpoczecia, data_zakonczenia]
            );

            console.log('Status inserted, ID:', result.insertId);
        }

        res.json({ message: 'Status zaktualizowany pomyślnie' });
    } catch (error) {
        console.error('Update status error:', error);
        console.error('Error stack:', error.stack);
        res.status(500).json({ message: 'Błąd serwera', error: error.message });
    }
});

module.exports = router;