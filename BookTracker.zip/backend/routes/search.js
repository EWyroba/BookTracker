const express = require('express');
const { authenticateToken } = require('../middleware/auth');
const axios = require('axios');
const router = express.Router();

// Wyszukaj książki w Google Books API
router.get('/', authenticateToken, async (req, res) => {
    try {
        const { q, maxResults = 10 } = req.query;

        if (!q) {
            return res.status(400).json({ message: 'Query parameter "q" is required' });
        }

        const response = await axios.get('https://www.googleapis.com/books/v1/volumes', {
            params: {
                q: q,
                maxResults: parseInt(maxResults),
                printType: 'books',
                langRestrict: 'pl'
            }
        });

        const books = response.data.items.map(item => {
            const volumeInfo = item.volumeInfo;
            return {
                googleBooksId: item.id,
                tytul: volumeInfo.title || 'Brak tytułu',
                autor: volumeInfo.authors ? volumeInfo.authors.join(', ') : 'Autor nieznany',
                isbn: volumeInfo.industryIdentifiers?.[0]?.identifier || '',
                opis: volumeInfo.description || '',
                liczba_stron: volumeInfo.pageCount || null,
                data_wydania: volumeInfo.publishedDate || '',
                wydawnictwo: volumeInfo.publisher || '',
                gatunek: volumeInfo.categories?.[0] || '',
                jezyk: volumeInfo.language || 'pl',
                url_okladki: volumeInfo.imageLinks?.thumbnail || volumeInfo.imageLinks?.smallThumbnail || '',
                previewLink: volumeInfo.previewLink || ''
            };
        });

        res.json({ books });
    } catch (error) {
        console.error('Google Books API error:', error);
        res.status(500).json({
            message: 'Błąd podczas wyszukiwania książek',
            error: error.message
        });
    }
});

// Szybkie dodanie książki z Google Books
router.post('/quick-add', authenticateToken, async (req, res) => {
    try {
        const { googleBooksId } = req.body;
        const db = require('../config/database');

        // Pobierz szczegóły książki z Google Books
        const response = await axios.get(`https://www.googleapis.com/books/v1/volumes/${googleBooksId}`);
        const volumeInfo = response.data.volumeInfo;

        // Dodaj książkę do bazy
        const [result] = await db.promisePool.execute(
            `INSERT INTO ksiazki 
       (tytul, autor, isbn, opis, liczba_stron, data_wydania, gatunek, jezyk, url_okladki) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                volumeInfo.title || 'Brak tytułu',
                volumeInfo.authors ? volumeInfo.authors.join(', ') : 'Autor nieznany',
                volumeInfo.industryIdentifiers?.[0]?.identifier || '',
                volumeInfo.description || '',
                volumeInfo.pageCount || null,
                volumeInfo.publishedDate || '',
                volumeInfo.categories?.[0] || '',
                volumeInfo.language || 'pl',
                volumeInfo.imageLinks?.thumbnail || volumeInfo.imageLinks?.smallThumbnail || ''
            ]
        );

        res.status(201).json({
            message: 'Książka dodana pomyślnie',
            bookId: result.insertId
        });
    } catch (error) {
        console.error('Quick add error:', error);
        res.status(500).json({
            message: 'Błąd podczas dodawania książki',
            error: error.message
        });
    }
});

module.exports = router;