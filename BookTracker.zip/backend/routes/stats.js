const express = require('express');
const { authenticateToken } = require('../middleware/auth');
const router = express.Router();

// Podstawowe statystyki użytkownika
router.get('/overview', authenticateToken, async (req, res) => {
    try {
        const db = require('../config/database');
        const userId = req.user.userId;

        // Przeczytane książki
        const [readBooks] = await db.promisePool.execute(
            `SELECT COUNT(*) as count 
       FROM statusy_czytania 
       WHERE uzytkownik_id = ? AND status = 'przeczytana'`,
            [userId]
        );

        // Książki w trakcie czytania
        const [readingBooks] = await db.promisePool.execute(
            `SELECT COUNT(*) as count 
       FROM statusy_czytania 
       WHERE uzytkownik_id = ? AND status = 'aktualnie_czytam'`,
            [userId]
        );

        // Łączna liczba stron
        const [totalPages] = await db.promisePool.execute(
            `SELECT SUM(k.liczba_stron) as total 
       FROM statusy_czytania s 
       JOIN ksiazki k ON s.ksiazka_id = k.id 
       WHERE s.uzytkownik_id = ? AND s.status = 'przeczytana'`,
            [userId]
        );

        // Statystyki gatunków
        const [genres] = await db.promisePool.execute(
            `SELECT k.gatunek, COUNT(*) as count 
       FROM statusy_czytania s 
       JOIN ksiazki k ON s.ksiazka_id = k.id 
       WHERE s.uzytkownik_id = ? AND s.status = 'przeczytana' AND k.gatunek IS NOT NULL
       GROUP BY k.gatunek 
       ORDER BY count DESC 
       LIMIT 10`,
            [userId]
        );

        // Książki przeczytane w tym roku (do wykresu)
        const [yearlyReading] = await db.promisePool.execute(
            `SELECT 
         MONTH(s.data_zakonczenia) as month,
         COUNT(*) as books_read
       FROM statusy_czytania s 
       WHERE s.uzytkownik_id = ? 
         AND s.status = 'przeczytana' 
         AND YEAR(s.data_zakonczenia) = YEAR(CURDATE())
       GROUP BY MONTH(s.data_zakonczenia)
       ORDER BY month`,
            [userId]
        );

        res.json({
            overview: {
                booksRead: readBooks[0].count || 0,
                currentlyReading: readingBooks[0].count || 0,
                totalPages: totalPages[0].total || 0,
                readingTime: Math.round((totalPages[0].total || 0) * 2.5 / 60) // średnio 2.5 min na stronę
            },
            genres: genres,
            yearlyReading: yearlyReading
        });
    } catch (error) {
        console.error('Stats overview error:', error);
        res.status(500).json({ message: 'Błąd serwera', error: error.message });
    }
});

// Statystyki czytania w czasie
router.get('/reading-timeline', authenticateToken, async (req, res) => {
    try {
        const db = require('../config/database');
        const userId = req.user.userId;
        const { period = 'year' } = req.query; // month, year

        let dateFormat, groupBy, dateRange;

        if (period === 'month') {
            dateFormat = '%Y-%m-%d';
            groupBy = 'DATE(s.data_zakonczenia)';
            dateRange = 'AND s.data_zakonczenia >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)';
        } else {
            dateFormat = '%Y-%m';
            groupBy = 'CONCAT(YEAR(s.data_zakonczenia), "-", LPAD(MONTH(s.data_zakonczenia), 2, "0"))';
            dateRange = 'AND s.data_zakonczenia >= DATE_SUB(CURDATE(), INTERVAL 1 YEAR)';
        }

        const [timeline] = await db.promisePool.execute(
            `SELECT 
         ${groupBy} as period,
         COUNT(*) as books_read,
         SUM(k.liczba_stron) as pages_read
       FROM statusy_czytania s 
       JOIN ksiazki k ON s.ksiazka_id = k.id 
       WHERE s.uzytkownik_id = ? 
         AND s.status = 'przeczytana' 
         AND s.data_zakonczenia IS NOT NULL
         ${dateRange}
       GROUP BY period
       ORDER BY period`,
            [userId]
        );

        res.json({ timeline });
    } catch (error) {
        console.error('Reading timeline error:', error);
        res.status(500).json({ message: 'Błąd serwera', error: error.message });
    }
});

// Cele czytelnicze
router.get('/reading-goals', authenticateToken, async (req, res) => {
    try {
        const db = require('../config/database');
        const userId = req.user.userId;

        // Pobierz cel użytkownika
        const [userGoals] = await db.promisePool.execute(
            'SELECT cel_czytania FROM uzytkownicy WHERE id = ?',
            [userId]
        );

        const yearlyGoal = userGoals[0]?.cel_czytania || 0;

        // Przeczytane książki w tym roku
        const [yearlyProgress] = await db.promisePool.execute(
            `SELECT COUNT(*) as count 
       FROM statusy_czytania 
       WHERE uzytkownik_id = ? 
         AND status = 'przeczytana' 
         AND YEAR(data_zakonczenia) = YEAR(CURDATE())`,
            [userId]
        );

        const booksThisYear = yearlyProgress[0].count || 0;
        const progress = yearlyGoal > 0 ? Math.min((booksThisYear / yearlyGoal) * 100, 100) : 0;

        res.json({
            goal: yearlyGoal,
            current: booksThisYear,
            progress: progress,
            remaining: Math.max(yearlyGoal - booksThisYear, 0)
        });
    } catch (error) {
        console.error('Reading goals error:', error);
        res.status(500).json({ message: 'Błąd serwera', error: error.message });
    }
});

module.exports = router;